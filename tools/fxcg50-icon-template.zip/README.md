How to use Lephe's icon templates:

The icon is made of a number of layers, most of which change when the icon is
selected. Thus there are variants for unselected icon "(uns)" and variants for
selected icons "(sel)".

• Use "BG (uns)" and "BG (sel)" as the background. No changes to these layers
  are needed. In the XCF they are initially locked.

Normally the OS draws the name of the add-in (as set in the G3A header) over
the bottom part of the icon, with a special font. However, there are times when
the font is too large or lacks characters, and you want to draw the text
yourself.

• Use "Custom text (uns)" and "Custom text (sel)" to add custom text (in this
  case, make sure to set an empty add-in name in the G3A header with mkg3a to
  avoid having both names draw).

  The helper "Text boundaries" shows a 2-pixel region around the edge where
  text should not reach to avoid readability issues with nearby icons.

Then comes the dithering pattern. All icons have the same, so generally only
the color and contrast need to be changed.

• Use "Dither (uns)" and "Dithering (sel)" to get the dithered rectangle. I
  suggest using "Color » Colorize" in GIMP to change the color. The layer's
  positions are locked by default.

  The helper "Dithering corners" is the source from which the layer mask of
  "Dithering (uns)" and "Dithering (sel)" is derived; it's kept to allow edits
  but not needed for icons.

• Use "Layer (uns)" and "Layer (sel)" to get the lighting on the edge of the
  dithered rectangle. These are locked.

Finally comes the icon design. The basic idea is to draw the icon normally,
then duplicate the "Icon" layer into the "Shadow" layer, make the "Shadow"
layer black, move it down 1 or 2 pixels, and reduce its opacity.

To generate the unselected icon, enable all the "(uns)" layers, Icon and
Shadow, and export; to generate the selected icon, enable all the "(sel)"
layers, Icon and Shadow, and export again.

If you're using mkg3a, you might need to remove the alpha channel from the
exported icons afterwards because mkg3a doesn't like all PNG color formats.
